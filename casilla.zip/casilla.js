"use strict";
class Casilla {
	/**
	 * Crea una casilla dadas sus posiciones
	 * @constructor
	 * @param  {number} x guarda la posición en las columnas de la casilla
	 * @param  {number} y guarda la posición en las filas de la casilla
	 */
	constructor(x, y) {
		/**
		 * Posición de la casilla en el tablero
		 * @typedef {Object} pos
		 * @property {number} x The X Coordinate
		 * @property {number} y The Y Coordinate
		 */
		this._pos = {
			x: x,
			y: y
		}
		/**
		 * Objeto de la clase
		 * @typedef {Object} con
		 */
		this._con = null;
	}

	/**
	 * Getter que devuelve la posición de la casilla
	 * @type {pos}
	 */
	get pos() {
		return this._pos;
	}

	/**
	 * Getter y setter del contenido de la casilla
	 * @param {number} value
	 * @type {con}
	 */
	get con() {
		return this._con;
	}
	set con(value) {
		if (value !== null) {
			value.pos = this._pos;
		}
		this._con = value;
	}
}
//Exportamos la clase Casilla
module.exports = Casilla;